﻿/*
 * @Author: 翁良森
 * @Date: 2021-06-16 08:55:16
 * @LastEditTime: 2021-06-16 11:54:21
 * @LastEditors: Please set LastEditors
 * @Description: 表白程序
 * @FilePath: \.vscode\exercise\biaobei.cpp
 */
#include<iostream>
#include<cstring>
using namespace std;

void love()
{
	cout << "在吗(?˙▽˙?)" << endl;
	cout << endl;
	system("pause");
	cout << endl;
	cout << "做我女朋友好不好(*??╰╯`?)?" << endl;
	cout << endl;
	system("pause");
	cout << endl;
	cout << "房产证写你的名字" << endl;
	cout << endl;
	system("pause");
	cout << endl;
	cout << "保大" << endl;
	cout << endl;
	system("pause");
	cout << endl;
	cout << "我妈会游泳" << endl;
	cout << endl;
	system("pause");
	cout << endl;

	while (1)
	{
		cout << "做我女朋友好不好，请郑重回答我！！！" << endl;
		cout << "请回答1(同意)还是0(不同意)" << endl;
		system("pause");

		int a;
		cout << "请输入1或0" << endl;
		cin >> a;

		while (1)
		{
			int n;

			if (a)
			{
				cout << "好耶！我就知道你会同意的Ｏ(≧▽≦)Ｏ " << endl;
				break;
			}
			else
			{

				while (1)
				{

					if (0 == 0)
					{
						n++;


						switch (n)
						{
						case 1:
						{
							cout << "啊，不同意吗？请再考虑考虑(?﹏?)" << endl;
							if (a)
							{
								cout << "好耶！我就知道你会同意的Ｏ(≧▽≦)Ｏ " << endl;
								break;
							}

						}

						break;


						case 2:
						{
							cin >> a;
							cout << "我真的喜欢你啊" << endl;
							if (a)
							{
								//cout<<"好耶！我就知道你会同意的Ｏ(≧▽≦)Ｏ "<<endl;
								break;
							}

						}

						break;

						case 3:
						{
							cin >> a;
							cout << "我发誓会对你好的" << endl;
							if (a)
							{
								//cout<<"好耶！我就知道你会同意的Ｏ(≧▽≦)Ｏ "<<endl;
								break;
							}

						}

						break;


						case 4:
						{
							cin >> a;
							cout << "我都这样了你还不同意吗？" << endl;
							if (a)
							{
								//cout<<"好耶！我就知道你会同意的Ｏ(≧▽≦)Ｏ "<<endl;
								break;
							}

						}

						break;


						case 5:
						{
							cin >> a;
							cout << "最后一次机会了!!!同不同意！！别不识好歹！！" << endl;
							if (a)
							{
								cout << "算你识相！ " << endl;
								break;
							}

						}

						break;


						case 6:


							while (1)
							{
								cout << "去死吧，狗女人，傻逼！" << "  ";
							}


						default:
							break;
						}

					}
					break;

				}


			}
			//break;

		}

		break;
	}



}

int main()
{
	love();


	system("pause");
	return 0;
}